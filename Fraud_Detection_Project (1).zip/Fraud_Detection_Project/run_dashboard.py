"""
STREAMLIT DASHBOARD LAUNCHER
Quick start guide and launcher for the Fraud Detection Dashboard
"""

import subprocess
import sys
import os

def main():
    """Launch Streamlit dashboard."""
    project_root = os.path.dirname(os.path.abspath(__file__))
    dashboard_path = os.path.join(project_root, 'dashboard.py')
    
    print("=" * 80)
    print("🚀 FRAUD DETECTION DASHBOARD - STREAMLIT")
    print("=" * 80)
    print()
    print("Launching Streamlit dashboard...")
    print()
    print("📌 Dashboard URL: http://localhost:8501")
    print()
    print("Press CTRL+C to stop the server")
    print("=" * 80)
    print()
    
    # Launch Streamlit
    subprocess.run([
        sys.executable, '-m', 'streamlit', 'run', dashboard_path,
        '--logger.level=warning'
    ])

if __name__ == '__main__':
    main()
