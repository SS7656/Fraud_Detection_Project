"""
INDUSTRY-GRADE FRAUD DETECTION PIPELINE
Unsupervised Machine Learning for Financial Fraud Detection
Uses Isolation Forest for anomaly detection with risk segmentation
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
import warnings
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler, LabelEncoder

warnings.filterwarnings('ignore')

# ============================================================================
# 1. CONFIGURATION & SETUP
# ============================================================================

def setup_paths():
    """Setup project directory paths correctly."""
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    # Define paths
    paths = {
        'base': BASE_DIR,
        'data_raw': os.path.join(BASE_DIR, 'data', 'raw'),
        'data_processed': os.path.join(BASE_DIR, 'data', 'processed'),
        'charts': os.path.join(BASE_DIR, 'outputs', 'charts'),
    }
    
    # Create directories if they don't exist
    os.makedirs(paths['data_processed'], exist_ok=True)
    os.makedirs(paths['charts'], exist_ok=True)
    
    return paths

# ============================================================================
# 2. LOAD DATA
# ============================================================================

def load_data(paths):
    """Load dataset from raw data directory."""
    # Find CSV file in raw directory or parent directories
    raw_dir = paths['data_raw']
    csv_files = [f for f in os.listdir(raw_dir) if f.endswith('.csv')] if os.path.exists(raw_dir) else []
    
    # If not found in current raw dir, search parent Fraud_Detection_Project
    if not csv_files:
        parent_raw = os.path.join(paths['base'], 'Fraud_Detection_Project', 'data', 'raw')
        if os.path.exists(parent_raw):
            csv_files = [f for f in os.listdir(parent_raw) if f.endswith('.csv')]
            if csv_files:
                raw_dir = parent_raw
    
    if not csv_files:
        raise FileNotFoundError(f"No CSV files found in {raw_dir}")
    
    data_path = os.path.join(raw_dir, csv_files[0])
    df = pd.read_csv(data_path)
    
    print("✅ LOAD DATA")
    print(f"   Dataset loaded from: {data_path}")
    print(f"   Shape: {df.shape}")
    print(f"   Columns: {list(df.columns)}\n")
    
    return df, data_path

# ============================================================================
# 3. DATA CLEANING
# ============================================================================

def clean_data(df):
    """
    Clean data with robust handling:
    - Replace invalid values (NM, No Data, _) with NaN
    - Convert numeric columns safely
    - Handle Credit_History_Age conversion
    - Apply median imputation instead of dropping rows
    """
    print("✅ CLEANING DATA")
    
    df_clean = df.copy()
    
    # Step 1: Replace common invalid markers with NaN
    invalid_markers = ['NM', 'No Data', '_', 'NA', 'N/A', 'null', '-']
    df_clean = df_clean.replace(invalid_markers, np.nan)
    
    # Step 2: Define numeric columns
    numeric_cols = [
        'Age', 'Annual_Income', 'Monthly_Inhand_Salary', 'Num_Bank_Accounts',
        'Num_Credit_Card', 'Interest_Rate', 'Num_of_Loan', 'Delay_from_due_date',
        'Num_of_Delayed_Payment', 'Changed_Credit_Limit', 'Num_Credit_Inquiries',
        'Outstanding_Debt', 'Credit_Utilization_Ratio', 'Credit_History_Age',
        'Total_EMI_per_month', 'Amount_invested_monthly', 'Monthly_Balance'
    ]
    
    # Convert numeric columns safely
    for col in numeric_cols:
        if col in df_clean.columns:
            df_clean[col] = pd.to_numeric(df_clean[col], errors='coerce')
    
    # Step 3: Handle Credit_History_Age (convert from string like "12 Years" to numeric)
    if 'Credit_History_Age' in df_clean.columns:
        def convert_age_to_years(val):
            if pd.isna(val):
                return np.nan
            if isinstance(val, str):
                # Extract numeric part (e.g., "12 Years" → 12)
                val_str = str(val).split()[0]
                try:
                    return float(val_str)
                except:
                    return np.nan
            return float(val)
        
        df_clean['Credit_History_Age'] = df_clean['Credit_History_Age'].apply(convert_age_to_years)
    
    # Step 4: Apply median imputation instead of dropping rows
    for col in numeric_cols:
        if col in df_clean.columns and df_clean[col].isna().sum() > 0:
            median_val = df_clean[col].median()
            df_clean[col].fillna(median_val, inplace=True)
    
    # Step 5: Handle categorical missing values
    categorical_cols = df_clean.select_dtypes(include=['object']).columns.tolist()
    for col in categorical_cols:
        if df_clean[col].isna().sum() > 0:
            df_clean[col].fillna(df_clean[col].mode()[0] if not df_clean[col].mode().empty else 'Unknown', inplace=True)
    
    print(f"   Rows: {len(df_clean)} | Columns: {len(df_clean.columns)}")
    print(f"   Missing values: {df_clean.isna().sum().sum()}")
    print(f"   Data types: {dict(df_clean.dtypes.astype(str).value_counts())}\n")
    
    return df_clean, numeric_cols

# ============================================================================
# 4. FEATURE ENGINEERING
# ============================================================================

def engineer_features(df, numeric_cols):
    """Create new features for fraud detection."""
    print("✅ FEATURE ENGINEERING")
    
    df_fe = df.copy()
    
    # Feature 1: Debt-to-Income Ratio
    # Rationale: High debt relative to income indicates financial stress, fraud alarm
    if 'Outstanding_Debt' in df_fe.columns and 'Annual_Income' in df_fe.columns:
        df_fe['Debt_To_Income_Ratio'] = (
            df_fe['Outstanding_Debt'] / (df_fe['Annual_Income'] + 1)
        )
    
    # Feature 2: Payment Delay Ratio
    # Rationale: High delay frequency indicates payment issues, potential fraud marker
    if 'Num_of_Delayed_Payment' in df_fe.columns and 'Num_of_Loan' in df_fe.columns:
        df_fe['Delay_Ratio'] = (
            df_fe['Num_of_Delayed_Payment'] / (df_fe['Num_of_Loan'] + 1)
        )
    
    # Feature 3: High Credit Utilization Flag
    # Rationale: >80% utilization is risky financial behavior
    if 'Credit_Utilization_Ratio' in df_fe.columns:
        df_fe['Utilization_Flag'] = (df_fe['Credit_Utilization_Ratio'] > 0.8).astype(int)
    
    print(f"   Created features: Debt_To_Income_Ratio, Delay_Ratio, Utilization_Flag\n")
    
    return df_fe

# ============================================================================
# 5. ENCODE CATEGORICAL FEATURES
# ============================================================================

def encode_categorical(df):
    """Encode categorical features using LabelEncoder."""
    print("✅ ENCODING CATEGORICAL FEATURES")
    
    df_encoded = df.copy()
    
    categorical_cols = df_encoded.select_dtypes(include=['object']).columns.tolist()
    encoders = {}
    
    for col in categorical_cols:
        le = LabelEncoder()
        df_encoded[col + '_Encoded'] = le.fit_transform(df_encoded[col].astype(str))
        encoders[col] = le
    
    print(f"   Encoded {len(categorical_cols)} categorical columns\n")
    
    return df_encoded, encoders

# ============================================================================
# 6. VISUALIZATION - 6 DIFFERENT CHART TYPES
# ============================================================================

def create_visualizations(df, numeric_cols, paths):
    """Create 6 diverse visualizations for EDA."""
    print("✅ VISUALIZATION")
    
    sns.set_style("whitegrid")
    
    # 1. HISTOGRAM with KDE - Age Distribution
    plt.figure(figsize=(10, 6))
    sns.histplot(df['Age'], bins=30, kde=True, color='skyblue', edgecolor='black')
    plt.title('1. Age Distribution (Histogram + KDE)', fontsize=14, fontweight='bold')
    plt.xlabel('Age')
    plt.ylabel('Frequency')
    plt.tight_layout()
    plt.savefig(os.path.join(paths['charts'], '01_age_histogram_kde.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # 2. BOXPLOT - Monthly Balance by Credit Score
    plt.figure(figsize=(10, 6))
    sns.boxplot(x='Credit_Score' if 'Credit_Score' in df.columns else 'Credit_Score_Encoded',
                y='Monthly_Balance', data=df, palette='Set2')
    plt.title('2. Monthly Balance by Credit Score (Boxplot)', fontsize=14, fontweight='bold')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(os.path.join(paths['charts'], '02_monthly_balance_boxplot.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # 3. SCATTER PLOT - Annual Income vs Outstanding Debt
    plt.figure(figsize=(10, 6))
    scatter_col = 'Credit_Score' if 'Credit_Score' in df.columns else 'Credit_Score_Encoded'
    sns.scatterplot(x='Annual_Income', y='Outstanding_Debt', hue=scatter_col,
                    data=df, s=50, alpha=0.6, palette='viridis')
    plt.title('3. Annual Income vs Outstanding Debt (Scatter)', fontsize=14, fontweight='bold')
    plt.xlabel('Annual Income')
    plt.ylabel('Outstanding Debt')
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=8)
    plt.tight_layout()
    plt.savefig(os.path.join(paths['charts'], '03_income_debt_scatter.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # 4. HEATMAP - Correlation Matrix
    plt.figure(figsize=(12, 10))
    numeric_for_corr = [col for col in numeric_cols if col in df.columns]
    corr_matrix = df[numeric_for_corr].corr()
    sns.heatmap(corr_matrix, annot=False, cmap='coolwarm', square=True,
                cbar_kws={'label': 'Correlation'}, linewidths=0.5)
    plt.title('4. Feature Correlation Heatmap', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig(os.path.join(paths['charts'], '04_correlation_heatmap.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # 5. LINE CHART - Credit History Age vs Credit Utilization Ratio
    if 'Credit_History_Age' in df.columns and 'Credit_Utilization_Ratio' in df.columns:
        plt.figure(figsize=(10, 6))
        df_sorted = df.sort_values('Credit_History_Age')
        plt.plot(df_sorted['Credit_History_Age'], df_sorted['Credit_Utilization_Ratio'],
                 marker='o', linestyle='-', color='steelblue', alpha=0.6, linewidth=2)
        plt.title('5. Credit History Age vs Utilization Ratio (Line)', fontsize=14, fontweight='bold')
        plt.xlabel('Credit History Age (Years)')
        plt.ylabel('Credit Utilization Ratio')
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(os.path.join(paths['charts'], '05_history_utilization_line.png'), dpi=300, bbox_inches='tight')
        plt.close()
    
    # 6. KDE PLOT - Outstanding Debt Distribution
    plt.figure(figsize=(10, 6))
    sns.kdeplot(data=df, x='Outstanding_Debt', fill=True, color='coral', alpha=0.6, linewidth=2)
    plt.title('6. Outstanding Debt Distribution (KDE)', fontsize=14, fontweight='bold')
    plt.xlabel('Outstanding Debt')
    plt.ylabel('Density')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(paths['charts'], '06_debt_kde.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"   Generated 6 visualizations")
    print(f"   Saved to: {paths['charts']}\n")

# ============================================================================
# 7. FRAUD DETECTION MODEL
# ============================================================================

def detect_fraud(df):
    """
    Unsupervised fraud detection using Isolation Forest.
    
    Algorithm Logic (Interview-Ready Explanation):
    - Isolation Forest builds random trees by splitting features
    - Anomalies (fraud cases) are isolated faster than normal points
    - Assigns anomaly scores: negative values = more anomalous
    - Normalize scores to 0-100 for business interpretation
    - Apply percentile-based thresholds for risk segmentation
    """
    print("✅ FRAUD DETECTION MODEL")
    
    # Select features for anomaly detection
    features_for_model = [
        'Annual_Income', 'Outstanding_Debt', 'Delay_from_due_date',
        'Num_of_Delayed_Payment', 'Num_Credit_Inquiries', 'Credit_Utilization_Ratio',
        'Debt_To_Income_Ratio', 'Delay_Ratio'
    ]
    
    # Filter to only existing columns
    features_available = [f for f in features_for_model if f in df.columns]
    
    # Feature Scaling: StandardScaler ensures all features contribute equally
    scaler = StandardScaler()
    df_scaled = scaler.fit_transform(df[features_available])
    
    # Isolation Forest: contamination=0.05 means ~5% expected fraud rate
    iso_forest = IsolationForest(contamination=0.05, random_state=42, n_estimators=100)
    iso_forest.fit(df_scaled)
    
    # Get raw anomaly scores (lower = more anomalous)
    raw_scores = iso_forest.score_samples(df_scaled)
    
    # Normalize scores to 0-100 range for business interpretation
    min_score = raw_scores.min()
    max_score = raw_scores.max()
    fraud_score_normalized = 100 * (1 - (raw_scores - min_score) / (max_score - min_score))
    df['Fraud_Risk_Score'] = fraud_score_normalized.astype(int)
    
    # Percentile-based risk segmentation
    p66 = np.percentile(df['Fraud_Risk_Score'], 66)
    p90 = np.percentile(df['Fraud_Risk_Score'], 90)
    
    def classify_risk(score):
        """Classify fraud risk into interpretable business categories."""
        if score < p66:
            return 'Low'
        elif score < p90:
            return 'Medium'
        else:
            return 'High'
    
    df['Fraud_Risk_Level'] = df['Fraud_Risk_Score'].apply(classify_risk)
    df['Is_Fraud'] = (df['Fraud_Risk_Level'] == 'High').astype(int)
    
    # Print results
    print(f"   Features used: {', '.join(features_available)}")
    print(f"   Fraud Risk Score range: {df['Fraud_Risk_Score'].min()} - {df['Fraud_Risk_Score'].max()}")
    print(f"\n   Risk Distribution:")
    print(f"   {df['Fraud_Risk_Level'].value_counts().to_string()}")
    print(f"\n   Flagged Fraud Cases (High Risk): {df['Is_Fraud'].sum()} ({df['Is_Fraud'].mean()*100:.2f}%)\n")
    
    return df

# ============================================================================
# 8. EXPORT RESULTS
# ============================================================================

def export_results(df, df_clean, paths):
    """Save cleaned data and fraud detection results."""
    print("✅ EXPORT RESULTS")
    
    # Save cleaned dataset
    cleaned_path = os.path.join(paths['data_processed'], 'cleaned_data.csv')
    df_clean.to_csv(cleaned_path, index=False)
    print(f"   Cleaned data → {cleaned_path}")
    
    # Save fraud detection results
    fraud_results_path = os.path.join(paths['data_processed'], 'fraud_results.csv')
    df.to_csv(fraud_results_path, index=False)
    print(f"   Fraud analysis → {fraud_results_path}")
    
    # Save flagged fraud cases only
    flagged_fraud = df[df['Is_Fraud'] == 1]
    flagged_path = os.path.join(paths['data_processed'], 'flagged_fraud_cases.csv')
    flagged_fraud.to_csv(flagged_path, index=False)
    print(f"   Flagged cases → {flagged_path}")
    
    # Summary statistics
    print(f"\n   Total records: {len(df)}")
    print(f"   Clean records: {len(df_clean)}")
    print(f"   Fraud flagged: {df['Is_Fraud'].sum()}\n")

# ============================================================================
# 9. MAIN EXECUTION
# ============================================================================

if __name__ == "__main__":
    print("\n" + "="*80)
    print("FRAUD DETECTION PIPELINE - INDUSTRY GRADE")
    print("="*80 + "\n")
    
    # Setup
    paths = setup_paths()
    
    # Load
    df_raw, data_path = load_data(paths)
    
    # Clean
    df_clean, numeric_cols = clean_data(df_raw)
    
    # Feature Engineering
    df_fe = engineer_features(df_clean, numeric_cols)
    
    # Encode
    df_encoded, encoders = encode_categorical(df_fe)
    
    # Visualize
    create_visualizations(df_encoded, numeric_cols, paths)
    
    # Detect Fraud
    df_results = detect_fraud(df_encoded)
    
    # Export
    export_results(df_results, df_clean, paths)
    
    print("="*80)
    print("✅ PIPELINE COMPLETED SUCCESSFULLY")
    print("="*80 + "\n")