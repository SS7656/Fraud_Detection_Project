"""
FRAUD DETECTION DASHBOARD
Interactive Streamlit Dashboard with 5 Visualization Types
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
import os
from datetime import datetime
import warnings

warnings.filterwarnings('ignore')

# ============================================================================
# PAGE CONFIGURATION
# ============================================================================

st.set_page_config(
    page_title="Fraud Detection Dashboard",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
    <style>
        body, html, .stApp, .main, .block-container, .css-1d391kg, .css-12oz5g7, .css-1r6slb0 {
            font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: radial-gradient(circle at top left, rgba(28, 63, 95, 0.75), transparent 20%),
                        linear-gradient(135deg, #08121f 0%, #081a2f 50%, #03111f 100%) !important;
            color: #f6f9ff !important;
        }
        .main .block-container {
            background: transparent !important;
            padding: 1.5rem 1.25rem !important;
        }
        .dashboard-panel {
            background: rgba(9, 18, 32, 0.85);
            border: 1px solid rgba(63, 182, 255, 0.18);
            border-radius: 28px;
            backdrop-filter: blur(18px);
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.35);
            padding: 1.5rem 1.75rem;
        }
        .header-box {
            background: rgba(2, 20, 44, 0.95);
            border: 1px solid rgba(102, 196, 255, 0.24);
            border-radius: 28px;
            padding: 1.2rem 1.4rem;
            display: inline-block;
            margin-bottom: 1rem;
            box-shadow: 0 18px 40px rgba(0, 0, 0, 0.25);
        }
        .header-box h1 {
            color: #ffffff !important;
            font-size: 2.55rem !important;
            margin: 0 !important;
            line-height: 1.05 !important;
        }
        .header-title {
            display: none !important;
        }
        .header-subtitle {
            color: #a9c8ff !important;
            font-size: 1rem !important;
            letter-spacing: 0.14em !important;
            text-transform: uppercase !important;
            margin-top: 0 !important;
            margin-bottom: 1.45rem !important;
        }
        .kpi-grid {
            display: grid !important;
            grid-template-columns: repeat(5, minmax(0, 1fr)) !important;
            gap: 1rem !important;
        }
        .kpi-card {
            background: rgba(11, 24, 42, 0.95);
            border: 1px solid rgba(63, 182, 255, 0.2);
            border-radius: 22px;
            padding: 1rem 1rem 1.1rem 1rem;
            color: #f6f9ff;
            min-height: 120px;
            box-shadow: 0 16px 40px rgba(0, 0, 0, 0.2);
        }
        .kpi-label {
            color: #ffffff !important;
            font-size: 0.88rem !important;
            letter-spacing: 0.12em !important;
            text-transform: uppercase !important;
            margin-bottom: 0.6rem !important;
        }
        .kpi-value {
            color: #ffffff !important;
            font-size: 1.85rem !important;
            font-weight: 800 !important;
            margin-bottom: 0.45rem !important;
        }
        .kpi-trend {
            color: #80d2ff !important;
            font-size: 0.95rem !important;
            font-weight: 600 !important;
        }
        .control-console {
            background: linear-gradient(180deg, rgba(2,14,30,0.96), rgba(7,27,48,0.92));
            border: 1px solid rgba(61, 193, 255, 0.18);
            border-radius: 28px;
            padding: 1.25rem;
            margin-bottom: 1.5rem;
            box-shadow: inset 0 0 0 1px rgba(255,255,255,0.05), 0 18px 45px rgba(0,0,0,0.25);
        }
        .control-console h3 {
            color: #b8d8ff !important;
            margin-bottom: 1rem !important;
            font-size: 1.1rem !important;
            letter-spacing: 0.12em !important;
            text-transform: uppercase !important;
        }
        .control-console .control-well {
            background: rgba(12, 29, 48, 0.88);
            border: 1px solid rgba(63, 182, 255, 0.14);
            border-radius: 16px;
            padding: 0.85rem 0.95rem;
            margin-bottom: 1rem;
        }
        .control-console label {
            color: #b8d8ff !important;
            font-size: 0.95rem !important;
            margin-bottom: 0.35rem !important;
            display: block !important;
        }
        .control-console .control-note {
            color: #87cefa !important;
            font-size: 0.82rem !important;
            margin-top: 0.25rem !important;
        }
        .insight-card {
            background: rgba(8, 17, 31, 0.95);
            border: 1px solid rgba(88, 183, 255, 0.2);
            border-radius: 24px;
            padding: 1.3rem;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.28);
        }
        .insight-card h3 {
            color: #ffffff !important;
            margin-top: 0 !important;
            margin-bottom: 1rem !important;
            font-size: 1.1rem !important;
        }
        .insight-card ul {
            padding-left: 1.2rem !important;
            color: #dcecff !important;
        }
        .insight-card li {
            margin-bottom: 0.8rem !important;
            line-height: 1.55 !important;
        }
        .footer-bar {
            background: rgba(2, 10, 22, 0.9);
            border-top: 1px solid rgba(63, 182, 255, 0.14);
            padding: 1rem 1.25rem;
            border-radius: 0 0 24px 24px;
            margin-top: 1.5rem;
            color: #8aa9d6;
            font-size: 0.92rem;
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 0.75rem;
        }
        .footer-actions span {
            color: #ffffff;
            background: rgba(31, 65, 108, 0.92);
            padding: 0.55rem 0.9rem;
            border-radius: 999px;
            border: 1px solid rgba(63, 182, 255, 0.16);
        }
        .footer-meta {
            color: #7aa1d0;
        }
        .chart-container {
            background-color: rgba(8, 17, 31, 0.95) !important;
            border: 1px solid rgba(63, 182, 255, 0.16) !important;
            border-radius: 24px !important;
            padding: 1.35rem !important;
            margin: 1.25rem 0 !important;
            box-shadow: 0 22px 52px rgba(0,0,0,0.28) !important;
            position: relative !important;
        }
        .chart-container::before {
            content: '';
            position: absolute;
            top: -1px;
            left: -1px;
            right: -1px;
            bottom: -1px;
            border-radius: 25px;
            background: linear-gradient(135deg, rgba(15, 108, 206, 0.25), rgba(101, 217, 255, 0.08));
            z-index: -1;
        }
        .chart-title {
            color: #7ec2ff !important;
            font-size: 1.4rem !important;
            font-weight: 700 !important;
            margin-bottom: 1rem !important;
            text-align: left !important;
        }
        .stSidebar {
            background: linear-gradient(180deg, rgba(4,23,44,0.96), rgba(3,17,31,0.96)) !important;
            color: #d2e7ff !important;
            border-right: 1px solid rgba(63, 182, 255, 0.18) !important;
        }
        .stSidebar .sidebar-content {
            color: #d2e7ff !important;
        }
        .stSidebar h1, .stSidebar h2, .stSidebar h3, .stSidebar h4, .stSidebar h5, .stSidebar h6 {
            color: #ffffff !important;
        }
        .stSidebar p, .stSidebar span, .stSidebar div, .stSidebar label {
            color: #c5dcff !important;
        }
        .stSidebar .stSelectbox, .stSidebar .stMultiselect, .stSidebar .stSlider {
            background-color: rgba(12, 27, 44, 0.96) !important;
            border: 1px solid rgba(63, 182, 255, 0.2) !important;
            border-radius: 14px !important;
        }
        .stSidebar .stSelectbox div, .stSidebar .stMultiselect div, .stSidebar .stSlider div {
            color: #f4fbff !important;
        }
        .stDataFrame {
            border: 1px solid rgba(63, 182, 255, 0.18) !important;
            border-radius: 18px !important;
        }
        .stDataFrame td, .stDataFrame th {
            color: #f0f8ff !important;
        }
        .stButton>button {
            background: linear-gradient(135deg, #1e68d5, #16b5ff) !important;
            color: #ffffff !important;
            border: none !important;
            border-radius: 999px !important;
            padding: 0.65rem 1.1rem !important;
            box-shadow: 0 12px 30px rgba(16, 105, 215, 0.28) !important;
        }
        .stButton>button:hover {
            transform: translateY(-1px) !important;
        }
    </style>
    """, unsafe_allow_html=True)

# ============================================================================
# LOAD DATA
# ============================================================================

@st.cache_data
def load_data():
    """Load fraud detection results with error handling."""
    try:
        # Try multiple paths for base directory
        possible_bases = [
            os.path.dirname(os.path.abspath(__file__)),
            os.getcwd(),
        ]
        
        fraud_results_path = None
        
        # Search for processed data files
        for base_dir in possible_bases:
            test_path = os.path.join(base_dir, 'data', 'processed', 'fraud_results.csv')
            if os.path.exists(test_path):
                fraud_results_path = test_path
                break
        
        if not fraud_results_path:
            return None, None
        
        df_all = pd.read_csv(fraud_results_path)
        
        # Ensure required columns exist with defaults
        if 'Fraud_Risk_Level' not in df_all.columns:
            df_all['Fraud_Risk_Level'] = 'Unknown'
        if 'Fraud_Risk_Score' not in df_all.columns:
            df_all['Fraud_Risk_Score'] = 0
        if 'Is_Fraud' not in df_all.columns:
            df_all['Is_Fraud'] = 0
        
        # Clean data
        df_all = df_all.dropna(subset=['Age', 'Annual_Income', 'Monthly_Balance', 'Outstanding_Debt'])
        
        flagged_path = os.path.join(os.path.dirname(fraud_results_path), 'flagged_fraud_cases.csv')
        if os.path.exists(flagged_path):
            df_flagged = pd.read_csv(flagged_path)
        else:
            df_flagged = df_all[df_all['Is_Fraud'] == 1]
        
        return df_all, df_flagged
        
    except Exception as e:
        st.error(f"Error loading data: {e}")
        return None, None

# ============================================================================
# HEADER & KPI METRICS
# ============================================================================

def display_header(df_all):
    """Display dashboard header and key metrics."""
    total_customers = len(df_all)
    anomalies = int(df_all['Is_Fraud'].sum()) if 'Is_Fraud' in df_all.columns else 0
    fraud_pct = (anomalies / total_customers * 100) if total_customers > 0 else 0
    avg_risk_index = df_all['Fraud_Risk_Score'].mean() if 'Fraud_Risk_Score' in df_all.columns else 0
    critical_customers = int(df_all[df_all['Fraud_Risk_Score'] >= 85]['Fraud_Risk_Score'].count()) if 'Fraud_Risk_Score' in df_all.columns else 0
    trend_flag = "↑" if fraud_pct > 18 else "↓"
    risk_change_label = "Moderate" if fraud_pct > 30 else "Stable"

    st.markdown("""
    <div class="header-box">
        <p style="color:#91caff; font-size:0.85rem; letter-spacing:0.14em; text-transform:uppercase; margin:0 0 0.85rem 0;">Behavioral & Anomaly-Based Analysis</p>
        <h1>🛡️ Paisabazaar Banking Fraud Analysis Dashboard</h1>
        <p style="color:#d8e8ff; margin:0.9rem 0 0 0; font-size:1rem;">Anomaly-based profiling powered by intelligence signals and customer behavioral insights.</p>
    </div>
    """, unsafe_allow_html=True)

    col1, col2, col3, col4, col5 = st.columns(5)
    with col1:
        st.markdown(f"""
            <div class="kpi-card">
                <div class="kpi-label">Active Customers</div>
                <div class="kpi-value">{total_customers:,}</div>
                <div class="kpi-trend">↓ 4.2% above baseline</div>
            </div>
        """, unsafe_allow_html=True)
    with col2:
        st.markdown(f"""
            <div class="kpi-card">
                <div class="kpi-label">Anomalous Profiles Detected</div>
                <div class="kpi-value">{anomalies:,}</div>
                <div class="kpi-trend">{trend_flag} elevated alerts</div>
            </div>
        """, unsafe_allow_html=True)
    with col3:
        st.markdown(f"""
            <div class="kpi-card">
                <div class="kpi-label">Fraud Risk Percentage</div>
                <div class="kpi-value">{fraud_pct:.1f}%</div>
                <div class="kpi-trend">{risk_change_label} exposure</div>
            </div>
        """, unsafe_allow_html=True)
    with col4:
        st.markdown(f"""
            <div class="kpi-card">
                <div class="kpi-label">Avg Credit Risk Index</div>
                <div class="kpi-value">{avg_risk_index:.1f}</div>
                <div class="kpi-trend">Based on score distribution</div>
            </div>
        """, unsafe_allow_html=True)
    with col5:
        st.markdown(f"""
            <div class="kpi-card">
                <div class="kpi-label">Critical Risk Customers</div>
                <div class="kpi-value">{critical_customers:,}</div>
                <div class="kpi-trend">Priority review required</div>
            </div>
        """, unsafe_allow_html=True)

    st.markdown("---")

# ============================================================================
# VIZ 1: RISK LEVEL DISTRIBUTION (PIE CHART)
# ============================================================================

def viz1_risk_distribution(df_display):
    """VIZ 1: Pie Chart - Fraud Risk Level Distribution"""
    st.markdown('<div class="chart-container">', unsafe_allow_html=True)
    st.markdown('<div class="chart-title">Risk Level Distribution</div>', unsafe_allow_html=True)
    try:
        risk_counts = df_display['Fraud_Risk_Level'].fillna('Unknown').value_counts()
        if len(risk_counts) == 0:
            st.warning("No data to display")
            st.markdown('</div>', unsafe_allow_html=True)
            return
        colors_map = {'Low': '#2ecc71', 'Medium': '#f39c12', 'High': '#e74c3c', 'Unknown': '#95a5a6'}
        colors = [colors_map.get(level, '#95a5a6') for level in risk_counts.index]
        fig = px.pie(
            values=risk_counts.values,
            names=risk_counts.index,
            hole=0.34,
            color_discrete_sequence=colors
        )
        fig.update_traces(textposition='inside', textinfo='percent+label', marker=dict(line=dict(color='#0b1728', width=2)))
        fig.update_layout(
            paper_bgcolor='rgba(8, 17, 31, 0.94)',
            plot_bgcolor='rgba(8, 17, 31, 0.94)',
            font=dict(color='white')
        )
        st.plotly_chart(fig, width='stretch')
    except Exception as e:
        st.error(f"Error in Risk Distribution: {e}")
    st.markdown('</div>', unsafe_allow_html=True)

# ============================================================================
# VIZ 2: FRAUD RISK SCORE DISTRIBUTION (HISTOGRAM)
# ============================================================================

def viz2_risk_score_histogram(df_display):
    """VIZ 2: Histogram - Fraud Risk Score Distribution"""
    st.markdown('<div class="chart-container">', unsafe_allow_html=True)
    st.markdown('<div class="chart-title">Fraud Risk Score Distribution</div>', unsafe_allow_html=True)
    try:
        if 'Fraud_Risk_Score' not in df_display.columns or len(df_display) == 0:
            st.warning("Risk score data not available")
            st.markdown('</div>', unsafe_allow_html=True)
            return
        fig = px.histogram(
            df_display,
            x='Fraud_Risk_Score',
            nbins=40,
            labels={'Fraud_Risk_Score': 'Risk Score', 'count': 'Customer Count'},
            color_discrete_sequence=['#3498db']
        )
        fig.add_vline(x=66, line_dash='dash', line_color='#ff9f43', annotation_text='66th percentile', annotation_position='top left')
        fig.add_vline(x=90, line_dash='dash', line_color='#ff4d4d', annotation_text='90th percentile', annotation_position='top right')
        fig.update_layout(
            paper_bgcolor='rgba(8, 17, 31, 0.94)',
            plot_bgcolor='rgba(8, 17, 31, 0.94)',
            font=dict(color='white'),
            xaxis=dict(gridcolor='rgba(255,255,255,0.08)'),
            yaxis=dict(gridcolor='rgba(255,255,255,0.08)')
        )
        st.plotly_chart(fig, width='stretch')
    except Exception as e:
        st.error(f"Error in Risk Score Histogram: {e}")
    st.markdown('</div>', unsafe_allow_html=True)

# ============================================================================
# VIZ 3: ANNUAL INCOME VS OUTSTANDING DEBT (SCATTER)
# ============================================================================

def viz3_scatter_income_debt(df_display):
    """VIZ 3: Scatter Plot - Annual Income vs Outstanding Debt"""
    st.markdown('<div class="chart-container">', unsafe_allow_html=True)
    st.markdown('<div class="chart-title">Annual Income vs Outstanding Debt</div>', unsafe_allow_html=True)
    try:
        df_scatter = df_display[['Annual_Income', 'Outstanding_Debt', 'Fraud_Risk_Level']].dropna()
        if len(df_scatter) == 0:
            st.warning("Insufficient data for scatter plot")
            st.markdown('</div>', unsafe_allow_html=True)
            return
        color_map = {'Low': '#2ecc71', 'Medium': '#f39c12', 'High': '#e74c3c', 'Unknown': '#95a5a6'}
        fig = px.scatter(
            df_scatter,
            x='Annual_Income',
            y='Outstanding_Debt',
            color='Fraud_Risk_Level',
            color_discrete_map=color_map,
            labels={'Annual_Income': 'Annual Income ($)', 'Outstanding_Debt': 'Outstanding Debt ($)'},
            opacity=0.75,
            size_max=12
        )
        fig.update_traces(marker=dict(size=8, line=dict(width=1, color='rgba(255,255,255,0.12)')))
        fig.update_layout(
            hovermode='closest',
            paper_bgcolor='rgba(8, 17, 31, 0.94)',
            plot_bgcolor='rgba(8, 17, 31, 0.94)',
            font=dict(color='white'),
            xaxis=dict(gridcolor='rgba(255,255,255,0.08)'),
            yaxis=dict(gridcolor='rgba(255,255,255,0.08)')
        )
        st.plotly_chart(fig, width='stretch')
    except Exception as e:
        st.error(f"Error in Scatter Plot: {e}")
    st.markdown('</div>', unsafe_allow_html=True)

# ============================================================================
# VIZ 4: BOXPLOT - MONTHLY BALANCE BY RISK LEVEL
# ============================================================================

def viz4_boxplot_balance(df_display):
    """VIZ 4: Boxplot - Monthly Balance Distribution by Risk Level"""
    st.markdown('<div class="chart-container">', unsafe_allow_html=True)
    st.markdown('<div class="chart-title">Monthly Balance by Risk Level</div>', unsafe_allow_html=True)
    try:
        df_box = df_display[['Monthly_Balance', 'Fraud_Risk_Level']].dropna()
        if len(df_box) == 0:
            st.warning("Insufficient data for boxplot")
            st.markdown('</div>', unsafe_allow_html=True)
            return
        fig = px.box(
            df_box,
            x='Fraud_Risk_Level',
            y='Monthly_Balance',
            color='Fraud_Risk_Level',
            color_discrete_map={'Low': '#2ecc71', 'Medium': '#f39c12', 'High': '#e74c3c', 'Unknown': '#95a5a6'},
            labels={'Monthly_Balance': 'Monthly Balance ($)', 'Fraud_Risk_Level': 'Risk Level'},
            points='all'
        )
        fig.update_layout(
            height=500,
            paper_bgcolor='rgba(8, 17, 31, 0.94)',
            plot_bgcolor='rgba(8, 17, 31, 0.94)',
            font=dict(color='white'),
            yaxis=dict(gridcolor='rgba(255,255,255,0.08)')
        )
        st.plotly_chart(fig, width='stretch')
    except Exception as e:
        st.error(f"Error in Boxplot: {e}")
    st.markdown('</div>', unsafe_allow_html=True)

# ============================================================================
# VIZ 5: LINE CHART - DELAYED PAYMENTS ANALYSIS
# ============================================================================

def viz5_delayed_payments_analysis(df_display):
    """VIZ 5: Line Chart - Delayed Payments Trend"""
    st.markdown('<div class="chart-container">', unsafe_allow_html=True)
    st.markdown('<div class="chart-title">Delayed Payments Analysis</div>', unsafe_allow_html=True)
    try:
        if 'Num_of_Delayed_Payment' not in df_display.columns:
            st.warning("Delayed payment data not available")
            st.markdown('</div>', unsafe_allow_html=True)
            return
        df_analysis = df_display[['Num_of_Delayed_Payment', 'Fraud_Risk_Level']].dropna()
        if len(df_analysis) == 0:
            st.warning("No delayed payment data")
            st.markdown('</div>', unsafe_allow_html=True)
            return
        delay_groups = pd.cut(df_analysis['Num_of_Delayed_Payment'], bins=10)
        analysis = df_analysis.groupby(delay_groups).size()
        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=[str(interval) for interval in analysis.index],
            y=analysis.values,
            mode='lines+markers',
            line=dict(color='#3498db', width=3),
            marker=dict(size=7)
        ))
        fig.update_layout(
            xaxis_title='Delayed Payment Range',
            yaxis_title='Number of Customers',
            hovermode='x unified',
            paper_bgcolor='rgba(8, 17, 31, 0.94)',
            plot_bgcolor='rgba(8, 17, 31, 0.94)',
            font=dict(color='white')
        )
        st.plotly_chart(fig, width='stretch')
    except Exception as e:
        st.error(f"Error in Line Chart: {e}")
    st.markdown('</div>', unsafe_allow_html=True)

# ============================================================================
# SIDEBAR FILTERS
# ============================================================================

def display_sidebar_filters(df_all):
    """Display sidebar with filter options."""
    st.sidebar.markdown("""
    <div style="background: linear-gradient(135deg, #001122, #2b3c52); padding: 18px; border-radius: 18px; margin-bottom: 24px; border: 1px solid rgba(84, 194, 255, 0.2); box-shadow: 0 16px 40px rgba(0,0,0,0.3);">
        <h2 style="color: #ffffff; font-weight: 900; font-size: 1.85rem; text-align: center; margin: 0; letter-spacing: 0.08em;">⚙️ Insights Console</h2>
        <p style="color: #b4d9ff; text-align: center; margin: 10px 0 0 0; font-size: 0.92rem;">Tune the risk view with premium filter controls.</p>
    </div>
    """, unsafe_allow_html=True)
    st.sidebar.markdown("---")

    filters = {}
    if 'Fraud_Risk_Level' in df_all.columns:
        unique_risks = sorted(df_all['Fraud_Risk_Level'].dropna().unique().tolist())
        filters['risk_levels'] = st.sidebar.multiselect(
            "Risk Category:",
            options=unique_risks,
            default=unique_risks,
            help="Filter customer segments by fraud risk category."
        )
    else:
        filters['risk_levels'] = None

    if 'Credit_Score' in df_all.columns:
        score_numeric = pd.to_numeric(df_all['Credit_Score'], errors='coerce')
        if score_numeric.notna().any():
            score_min = int(score_numeric.min())
            score_max = int(score_numeric.max())
            filters['credit_score'] = st.sidebar.slider(
                "Credit Score Range:",
                min_value=score_min,
                max_value=score_max,
                value=(score_min, score_max),
                step=1,
                help="Focus on specific credit score brackets."
            )
        else:
            unique_scores = sorted(df_all['Credit_Score'].dropna().unique().tolist())
            filters['credit_score'] = st.sidebar.multiselect(
                "Credit Score Category:",
                options=unique_scores,
                default=unique_scores,
                help="Filter by credit score category if numeric values are unavailable."
            )
    else:
        filters['credit_score'] = None

    if 'Annual_Income' in df_all.columns:
        income_min = int(df_all['Annual_Income'].min())
        income_max = int(df_all['Annual_Income'].max())
        filters['income_range'] = st.sidebar.slider(
            "Annual Income Range ($):",
            min_value=income_min,
            max_value=income_max,
            value=(income_min, income_max),
            step=max(1000, (income_max - income_min) // 20),
            help="Choose the customer income bracket for analysis."
        )
    else:
        filters['income_range'] = None

    if 'Outstanding_Debt' in df_all.columns:
        debt_min = int(df_all['Outstanding_Debt'].min())
        debt_max = int(df_all['Outstanding_Debt'].max())
        filters['debt_range'] = st.sidebar.slider(
            "Outstanding Debt Range ($):",
            min_value=debt_min,
            max_value=debt_max,
            value=(debt_min, debt_max),
            step=max(1000, (debt_max - debt_min) // 20),
            help="Exclude extreme debt exposures for clearer risk insights."
        )
    else:
        filters['debt_range'] = None

    if 'Monthly_Balance' in df_all.columns:
        balance_threshold = st.sidebar.slider(
            "Minimum Monthly Balance ($):",
            min_value=int(df_all['Monthly_Balance'].min()),
            max_value=int(df_all['Monthly_Balance'].max()),
            value=int(df_all['Monthly_Balance'].min()),
            step=max(100, int((df_all['Monthly_Balance'].max() - df_all['Monthly_Balance'].min()) // 20)),
            help="Surface customers with material monthly balance behavior."
        )
        filters['balance_threshold'] = balance_threshold
    else:
        filters['balance_threshold'] = None

    st.sidebar.markdown("---")
    return filters

# ============================================================================
# APPLY FILTERS
# ============================================================================

def apply_filters(df, filters):
    """Apply selected filters to dataframe."""
    df_filtered = df.copy()
    
    if filters.get('risk_levels') and 'Fraud_Risk_Level' in df_filtered.columns:
        df_filtered = df_filtered[df_filtered['Fraud_Risk_Level'].isin(filters['risk_levels'])]
    
    if filters.get('age_range') and 'Age' in df_filtered.columns:
        df_filtered = df_filtered[
            (df_filtered['Age'] >= filters['age_range'][0]) & 
            (df_filtered['Age'] <= filters['age_range'][1])
        ]
    
    if filters.get('income_range') and 'Annual_Income' in df_filtered.columns:
        df_filtered = df_filtered[
            (df_filtered['Annual_Income'] >= filters['income_range'][0]) & 
            (df_filtered['Annual_Income'] <= filters['income_range'][1])
        ]

    credit_filter = filters.get('credit_score')
    if credit_filter is not None and 'Credit_Score' in df_filtered.columns:
        credit_numeric = pd.to_numeric(df_filtered['Credit_Score'], errors='coerce')
        if isinstance(credit_filter, tuple):
            df_filtered = df_filtered[
                (credit_numeric >= credit_filter[0]) &
                (credit_numeric <= credit_filter[1])
            ]
        else:
            df_filtered = df_filtered[df_filtered['Credit_Score'].isin(credit_filter)]
    
    return df_filtered

# ============================================================================
# DETAILED DATA TABLE
# ============================================================================

def display_detailed_table(df_display):
    """Display detailed fraud cases table."""
    st.subheader("📋 Detailed Fraud Cases")
    
    if len(df_display) == 0:
        st.info("No records match the selected filters.")
        return
    
    # Select columns to display
    display_cols = [col for col in [
        'Age', 'Annual_Income', 'Outstanding_Debt', 'Credit_Utilization_Ratio',
        'Num_of_Delayed_Payment', 'Monthly_Balance', 'Fraud_Risk_Score', 'Fraud_Risk_Level', 'Is_Fraud'
    ] if col in df_display.columns]
    
    df_table = df_display[display_cols].sort_values('Fraud_Risk_Score', ascending=False).head(100)
    st.dataframe(df_table, width='stretch', height=400)


def display_insights_panel(df_display):
    """Display actionable insights in the dashboard."""
    st.markdown("""
    <div class="insight-card">
        <h3>Actionable Insights</h3>
        <ul>
            <li><strong>High-risk concentration:</strong> Focus review on segments with elevated fraud risk scores and debt exposure.</li>
            <li><strong>Credit utilization alert:</strong> Customers exceeding 75% utilization are prime candidates for fraud review.</li>
            <li><strong>Cluster signal:</strong> PCA clusters reveal hidden cohorts with similar risk patterns.</li>
            <li><strong>Balance outliers:</strong> Outlier analysis shows unusual monthly balance behavior in high-risk accounts.</li>
        </ul>
    </div>
    """, unsafe_allow_html=True)

# ============================================================================
# FOOTER
# ============================================================================

def display_footer():
    """Display dashboard footer."""
    st.markdown("---")
    st.markdown("""
    <div style='text-align: center; color: #7f8c8d; font-size: 0.9rem;'>
        <p>🔍 Fraud Detection Dashboard | Unsupervised Anomaly Detection | 2026</p>
    </div>
    """, unsafe_allow_html=True)

# ============================================================================
# MAIN APP
# ============================================================================

if __name__ == "__main__":
    # Load data
    df_all, df_flagged = load_data()
    
    if df_all is None:
        st.error("❌ Cannot load fraud detection data. Please run fraud_detection.py first.")
        st.info("📌 Command: python src/fraud_detection.py")
        st.stop()
    
    # Display header
    display_header(df_all)
    
    # Sidebar filters
    filters = display_sidebar_filters(df_all)
    
    # Apply filters
    df_filtered = apply_filters(df_all, filters)
    
    # Create tabs for organization
    tab1, tab2, tab3 = st.tabs(["📊 Visualizations", "📈 Analysis", "📥 Export"])
    
    with tab1:
        st.write(f"**Showing {len(df_filtered):,} of {len(df_all):,} records**")
        
        # Display 5 visualizations
        col1, col2 = st.columns(2)
        
        with col1:
            viz1_risk_distribution(df_filtered)
            viz2_risk_score_histogram(df_filtered)
        
        with col2:
            viz3_scatter_income_debt(df_filtered)
            viz4_boxplot_balance(df_filtered)
        
        # Full width visualization
        viz5_delayed_payments_analysis(df_filtered)
    
    with tab2:
        st.subheader("📊 Summary Statistics")
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("📋 Filtered Records", len(df_filtered))
        with col2:
            fraud_in_filtered = df_filtered['Is_Fraud'].sum() if 'Is_Fraud' in df_filtered.columns else 0
            st.metric("⚠️ Fraud Cases", int(fraud_in_filtered))
        with col3:
            if len(df_filtered) > 0:
                fraud_rate = (fraud_in_filtered / len(df_filtered) * 100)
                st.metric("📈 Fraud Rate", f"{fraud_rate:.2f}%")
        
        st.markdown("---")
        display_insights_panel(df_filtered)
        display_detailed_table(df_filtered)
    
    with tab3:
        st.subheader("📥 Export Data")
        
        try:
            # CSV download - filtered
            if len(df_filtered) > 0:
                csv_data = df_filtered.to_csv(index=False)
                st.download_button(
                    label="📥 Download Filtered Data (CSV)",
                    data=csv_data,
                    file_name=f"fraud_filtered_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv"
                )
                
                st.write(f"✅ {len(df_filtered)} records ready to download")
            else:
                st.warning("No records to download with current filters")
            
            # High risk cases download
            if 'Fraud_Risk_Level' in df_filtered.columns:
                high_risk = df_filtered[df_filtered['Fraud_Risk_Level'] == 'High']
                if len(high_risk) > 0:
                    high_risk_csv = high_risk.to_csv(index=False)
                    st.download_button(
                        label="🔴 Download High Risk Cases (CSV)",
                        data=high_risk_csv,
                        file_name=f"high_risk_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                        mime="text/csv"
                    )
                    st.write(f"✅ {len(high_risk)} high-risk cases ready")
        except Exception as e:
            st.error(f"Error in export: {e}")
    
    # Footer
    display_footer()
